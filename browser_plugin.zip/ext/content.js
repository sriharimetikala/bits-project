// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function(tab) {
  // Send a message to the active tab
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var activeTab = tabs[0];
	alert(activeTab.url)
	var domain = (new URL(activeTab.url)).hostname.replace('www.','');
	alert(domain)
	var url="http://localhost:8080/getReview/"+domain
	$.get( url, function( data ) {
	  $( ".result" ).html( data );
	  alert( "Load was performed." );
	});
	
    //chrome.tabs.sendMessage(activeTab.id, {"message": "clicked_browser_action"});
  });
});

document.addEventListener('DOMContentLoaded', function() {
// Send a message to the active tab
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var activeTab = tabs[0];
	//alert(activeTab.url)
	var domain = (new URL(activeTab.url)).hostname.replace('www.','');
	var url="http://24d667dd1020.ngrok.io/review?id="+domain
	$.get( url, function( data ) {
	  $( "#Overall" ).html( data.overallRating );
	  $( "#Delivery" ).html( data.deliveryRating );
	  $( "#Support" ).html( data.supportRating );
	  $( "#Pricing" ).html( data.pricingRating );
	  $( "#Quality" ).html( data.qualityRating );
	  
	  $( ".bar-5" ).width( data.deliveryRating.split(' ')[0] );
	  $( ".bar-4" ).width( data.pricingRating.split(' ')[0] );
	  $( ".bar-3" ).width( data.supportRating.split(' ')[0] );
	  $( ".bar-2" ).width( data.qualityRating.split(' ')[0]);

	});
	
    //chrome.tabs.sendMessage(activeTab.id, {"message": "clicked_browser_action"});
  });
}, false);