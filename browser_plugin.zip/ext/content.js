document.addEventListener('DOMContentLoaded', function() {
// Send a message to the active tab
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var activeTab = tabs[0];
	//alert(activeTab.url)
	var domain = (new URL(activeTab.url)).hostname.replace('www.','');
	var url="http://5235718a0bbf.ngrok.io/review?id="+domain
	$.getJSON( url, function( data ) {
	  jsondata=data[0];	
	  var ratingStar=parseInt(jsondata.site_overallRatingStar)
	  for(var i=0;i<ratingStar;i++){
		$( "#overAllRate_"+(i+1)).addClass('checked');
	  }	  
	  $( "#Overall" ).html(  jsondata.overallRating );
	  $( "#Delivery" ).html( jsondata.deliveryRating );
	  $( "#Support" ).html( jsondata.supportRating );
	  $( "#Pricing" ).html( jsondata.pricingRating );
	  $( "#Quality" ).html( jsondata.qualityRating );
	  
	  $( ".bar-5" ).width( jsondata.deliveryRating.split(' ')[0] );
	  $( ".bar-4" ).width( jsondata.pricingRating.split(' ')[0] );
	  $( ".bar-3" ).width( jsondata.supportRating.split(' ')[0] );
	  $( ".bar-2" ).width( jsondata.qualityRating.split(' ')[0]);

	});
	
    //chrome.tabs.sendMessage(activeTab.id, {"message": "clicked_browser_action"});
  });
}, false);